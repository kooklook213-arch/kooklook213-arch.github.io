"use client";

import { useEffect, useRef, useState } from "react";
import { Search, KeyRound, ExternalLink, Building2, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChatSidebar } from "@/components/chat/sidebar";
import { RightPanel } from "@/components/chat/right-panel";
import { ThinkingSphere } from "@/components/chat/thinking-sphere";
import { ApiKeysDialog } from "@/components/chat/api-keys-dialog";
import { useChatStore, uid, type ChatMessage, JOB_SEARCH_SYSTEM_PROMPT } from "@/lib/chat-store";
import { extractArtifacts } from "@/lib/extract-artifacts";

type Job = { title: string; company: string; location: string; url: string; summary: string };

function parseJobs(content: string): Job[] {
  const artifacts = extractArtifacts(content, "jobs");
  const jsonBlock = artifacts.find((a) => a.language === "json");
  if (!jsonBlock) return [];
  try {
    const parsed = JSON.parse(jsonBlock.code);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((j) => j && j.title && j.url);
  } catch {
    return [];
  }
}

export default function JobsPage() {
  const { activeThread, activeThreadId, appendMessage, updateMessage, settings } = useChatStore();
  const [role, setRole] = useState("");
  const [location, setLocation] = useState("");
  const [keywords, setKeywords] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [panelOpen, setPanelOpen] = useState(false);
  const [panelTab, setPanelTab] = useState<"artifacts" | "connections" | "skills">("artifacts");
  const [apiKeysOpen, setApiKeysOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activeThread?.messages.length, activeThread?.messages]);

  const search = async () => {
    if (!role.trim() || !activeThreadId || busy) return;
    if (!settings.apiKey) {
      setError("Add your Anthropic API key first (API keys button in the sidebar).");
      setApiKeysOpen(true);
      return;
    }

    setError("");
    const criteria = [
      `Role: ${role.trim()}`,
      location.trim() && `Location: ${location.trim()}`,
      keywords.trim() && `Other criteria: ${keywords.trim()}`,
    ]
      .filter(Boolean)
      .join("\n");

    const userMsg: ChatMessage = { id: uid(), role: "user", content: criteria, createdAt: Date.now() };
    appendMessage(activeThreadId, userMsg, { titleIfEmpty: role.trim() });

    const assistantId = uid();
    appendMessage(activeThreadId, { id: assistantId, role: "assistant", content: "", createdAt: Date.now(), streaming: true });

    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        signal: controller.signal,
        headers: { "content-type": "application/json", "x-api-key": settings.apiKey },
        body: JSON.stringify({
          model: settings.model,
          system: JOB_SEARCH_SYSTEM_PROMPT,
          messages: [{ role: "user", content: criteria }],
          webSearch: true, // job search is meaningless without live results
        }),
      });

      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Request failed (${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const jsonStr = line.slice(5).trim();
          if (!jsonStr) continue;
          try {
            const evt = JSON.parse(jsonStr);
            if (evt.type === "content_block_delta" && evt.delta?.type === "text_delta") {
              full += evt.delta.text;
              updateMessage(activeThreadId, assistantId, { content: full, streaming: true }, { persist: false });
            } else if (evt.type === "error") {
              throw new Error(evt.error?.message || "Streaming error.");
            }
          } catch {
            // ignore partial lines
          }
        }
      }

      updateMessage(activeThreadId, assistantId, { content: full, streaming: false }, { persist: true });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      updateMessage(activeThreadId, assistantId, { content: `⚠️ ${message}`, streaming: false }, { persist: true });
      if (!message.startsWith("The user aborted")) setError(message);
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const latestAssistant = [...(activeThread?.messages || [])].reverse().find((m) => m.role === "assistant");
  const jobs = latestAssistant && !latestAssistant.streaming ? parseJobs(latestAssistant.content) : [];

  return (
    <div className="flex h-screen overflow-hidden">
      <ChatSidebar
        onOpenArtifacts={() => {
          setPanelTab("artifacts");
          setPanelOpen(true);
        }}
        onOpenConnections={() => {
          setPanelTab("connections");
          setPanelOpen(true);
        }}
        onOpenSkills={() => {
          setPanelTab("skills");
          setPanelOpen(true);
        }}
        onOpenPlugins={() => {}}
        onOpenApiKeys={() => setApiKeysOpen(true)}
      />

      <main className="flex-1 flex flex-col min-w-0">
        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-6 py-10">
            <div className="mb-8">
              <h1 className="text-3xl font-display tracking-tight mb-2">Job finder</h1>
              <p className="text-muted-foreground text-sm">
                Searches the live web for real, current openings matching your criteria.
              </p>
            </div>

            <div className="rounded-2xl border border-foreground/15 bg-secondary/40 p-4 mb-8 space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <Input
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  placeholder="Role — e.g. Senior Frontend Engineer"
                  className="h-11 rounded-lg"
                  onKeyDown={(e) => e.key === "Enter" && search()}
                />
                <Input
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Location — e.g. Remote, or Austin TX"
                  className="h-11 rounded-lg"
                  onKeyDown={(e) => e.key === "Enter" && search()}
                />
              </div>
              <Input
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="Anything else — seniority, salary range, industry, skills…"
                className="h-11 rounded-lg"
                onKeyDown={(e) => e.key === "Enter" && search()}
              />
              <div className="flex justify-between items-center">
                {!settings.apiKey ? (
                  <Button variant="outline" size="sm" className="rounded-full" onClick={() => setApiKeysOpen(true)}>
                    <KeyRound className="w-3.5 h-3.5 mr-2" />
                    Add API key
                  </Button>
                ) : (
                  <span />
                )}
                <Button
                  onClick={search}
                  disabled={busy || !role.trim()}
                  className="rounded-full bg-foreground text-background hover:bg-foreground/90 disabled:opacity-40"
                >
                  <Search className="w-4 h-4 mr-2" />
                  {busy ? "Searching…" : "Search"}
                </Button>
              </div>
            </div>

            {error && <p className="text-sm text-destructive mb-4">{error}</p>}

            {busy && (!latestAssistant || latestAssistant.streaming) && <ThinkingSphere label="Searching the web" />}

            {!busy && latestAssistant && !latestAssistant.streaming && jobs.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No matching listings came back — try broadening the role or dropping a filter.
              </p>
            )}

            <div className="flex flex-col gap-3">
              {jobs.map((job, i) => (
                <a
                  key={i}
                  href={job.url}
                  target="_blank"
                  rel="noreferrer"
                  className="group rounded-xl border border-foreground/10 p-4 hover:border-foreground/30 transition-colors block"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{job.title}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {job.company}
                        </span>
                        {job.location && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {job.location}
                          </span>
                        )}
                      </div>
                      {job.summary && <p className="text-sm text-muted-foreground mt-2">{job.summary}</p>}
                    </div>
                    <ExternalLink className="w-4 h-4 shrink-0 text-muted-foreground group-hover:text-foreground transition-colors mt-1" />
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </main>

      <RightPanel
        open={panelOpen}
        defaultTab={panelTab}
        thread={activeThread}
        focusArtifactId={null}
        onClose={() => setPanelOpen(false)}
      />

      <ApiKeysDialog open={apiKeysOpen} onOpenChange={setApiKeysOpen} />
    </div>
  );
}
