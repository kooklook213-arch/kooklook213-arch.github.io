"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, Square, KeyRound, CheckCircle2, Circle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ChatSidebar } from "@/components/chat/sidebar";
import { RightPanel } from "@/components/chat/right-panel";
import { MessageBubble } from "@/components/chat/message-bubble";
import { ThinkingSphere } from "@/components/chat/thinking-sphere";
import { ApiKeysDialog } from "@/components/chat/api-keys-dialog";
import {
  useChatStore,
  uid,
  type ChatMessage,
  AGENT_PLAN_SYSTEM_PROMPT,
  AGENT_STEP_SYSTEM_PROMPT,
} from "@/lib/chat-store";
import { useSpeech } from "@/lib/use-speech";

type StepStatus = "pending" | "running" | "done";

function parsePlanSteps(text: string): string[] {
  return text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => /^\d+[.)]/.test(l))
    .map((l) => l.replace(/^\d+[.)]\s*/, "").trim())
    .filter(Boolean);
}

export default function AgentPage() {
  const { activeThread, activeThreadId, appendMessage, updateMessage, settings } = useChatStore();
  const [goal, setGoal] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [panelOpen, setPanelOpen] = useState(false);
  const [panelTab, setPanelTab] = useState<"artifacts" | "connections" | "skills">("artifacts");
  const [focusArtifactId, setFocusArtifactId] = useState<string | null>(null);
  const [apiKeysOpen, setApiKeysOpen] = useState(false);
  const [plan, setPlan] = useState<string[]>([]);
  const [stepStatuses, setStepStatuses] = useState<StepStatus[]>([]);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stoppedRef = useRef(false);

  const { speak } = useSpeech();

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activeThread?.messages.length, activeThread?.messages]);

  // Reset the visible plan when switching threads.
  useEffect(() => {
    setPlan([]);
    setStepStatuses([]);
  }, [activeThreadId]);

  const streamCompletion = async (
    history: { role: "user" | "assistant"; content: string }[],
    system: string,
    assistantMessageId: string,
    controller: AbortController
  ): Promise<string> => {
    const res = await fetch("/api/chat", {
      method: "POST",
      signal: controller.signal,
      headers: { "content-type": "application/json", "x-api-key": settings.apiKey },
      body: JSON.stringify({
        model: settings.model,
        system,
        messages: history,
        webSearch: settings.plugins.webSearch,
      }),
    });

    if (!res.ok || !res.body) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || `Request failed (${res.status})`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let full = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const jsonStr = line.slice(5).trim();
        if (!jsonStr) continue;
        try {
          const evt = JSON.parse(jsonStr);
          if (evt.type === "content_block_delta" && evt.delta?.type === "text_delta") {
            full += evt.delta.text;
            if (activeThreadId) {
              updateMessage(activeThreadId, assistantMessageId, { content: full, streaming: true }, { persist: false });
            }
          } else if (evt.type === "error") {
            throw new Error(evt.error?.message || "Streaming error.");
          }
        } catch {
          // ignore partial/malformed lines
        }
      }
    }
    return full;
  };

  const runAgent = async (goalText: string) => {
    const content = goalText.trim();
    if (!content || !activeThreadId || busy) return;

    if (!settings.apiKey) {
      setError("Add your Anthropic API key first (API keys button in the sidebar).");
      setApiKeysOpen(true);
      return;
    }

    setError("");
    setGoal("");
    stoppedRef.current = false;
    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;

    const userMsg: ChatMessage = { id: uid(), role: "user", content, createdAt: Date.now() };
    appendMessage(activeThreadId, userMsg, { titleIfEmpty: content });

    try {
      // 1. Plan
      const planMsgId = uid();
      appendMessage(activeThreadId, { id: planMsgId, role: "assistant", content: "", createdAt: Date.now(), streaming: true });
      const planText = await streamCompletion(
        [{ role: "user", content }],
        AGENT_PLAN_SYSTEM_PROMPT,
        planMsgId,
        controller
      );
      updateMessage(activeThreadId, planMsgId, { content: planText, streaming: false }, { persist: true });

      const steps = parsePlanSteps(planText);
      if (steps.length === 0) {
        setBusy(false);
        return;
      }
      setPlan(steps);
      setStepStatuses(steps.map(() => "pending"));

      // 2. Execute steps sequentially
      const priorOutputs: string[] = [];
      for (let i = 0; i < steps.length; i++) {
        if (stoppedRef.current) break;
        setStepStatuses((prev) => prev.map((s, idx) => (idx === i ? "running" : s)));

        const stepMsgId = uid();
        appendMessage(activeThreadId, {
          id: stepMsgId,
          role: "assistant",
          content: "",
          createdAt: Date.now(),
          streaming: true,
        });

        const stepHistory = [
          { role: "user" as const, content: `Goal: ${content}\n\nFull plan:\n${planText}` },
          {
            role: "user" as const,
            content: `Prior step outputs so far:\n${priorOutputs.map((o, idx) => `Step ${idx + 1}: ${o.slice(0, 400)}`).join("\n\n") || "(none yet)"}\n\nNow execute step ${i + 1}: ${steps[i]}`,
          },
        ];

        let stepText = "";
        try {
          stepText = await streamCompletion(stepHistory, AGENT_STEP_SYSTEM_PROMPT, stepMsgId, controller);
        } catch (err) {
          const message = err instanceof Error ? err.message : "Step failed.";
          updateMessage(activeThreadId, stepMsgId, { content: `⚠️ ${message}`, streaming: false }, { persist: true });
          setStepStatuses((prev) => prev.map((s, idx) => (idx === i ? "done" : s)));
          break;
        }

        const labeled = `**Step ${i + 1} — ${steps[i]}**\n\n${stepText}`;
        updateMessage(activeThreadId, stepMsgId, { content: labeled, streaming: false }, { persist: true });
        priorOutputs.push(stepText);
        setStepStatuses((prev) => prev.map((s, idx) => (idx === i ? "done" : s)));

        if (/```/.test(labeled)) {
          setFocusArtifactId(`${stepMsgId}-0`);
          setPanelTab("artifacts");
          setPanelOpen(true);
        }
      }

      if (settings.plugins.voiceOut && !stoppedRef.current) {
        speak(`Finished working through the plan for: ${content}`);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      if (!message.startsWith("The user aborted")) setError(message);
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const stop = () => {
    stoppedRef.current = true;
    abortRef.current?.abort();
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <ChatSidebar
        onOpenArtifacts={() => {
          setPanelTab("artifacts");
          setPanelOpen(true);
        }}
        onOpenConnections={() => {
          setPanelTab("connections");
          setPanelOpen(true);
        }}
        onOpenSkills={() => {
          setPanelTab("skills");
          setPanelOpen(true);
        }}
        onOpenPlugins={() => {}}
        onOpenApiKeys={() => setApiKeysOpen(true)}
      />

      <main className="flex-1 flex min-w-0">
        <div className="flex-1 flex flex-col min-w-0">
          <div ref={scrollRef} className="flex-1 overflow-y-auto">
            <div className="max-w-3xl mx-auto px-6 py-10 flex flex-col gap-6">
              {(!activeThread || activeThread.messages.length === 0) && (
                <div className="py-20 text-center">
                  <h1 className="text-4xl font-display tracking-tight mb-3">Give the agent a goal</h1>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Describe an outcome, not steps — the agent plans a short sequence, then works
                    through it, checking each step off as it goes.
                  </p>
                  {!settings.apiKey && (
                    <Button variant="outline" className="mt-6 rounded-full" onClick={() => setApiKeysOpen(true)}>
                      <KeyRound className="w-4 h-4 mr-2" />
                      Add your API key to get started
                    </Button>
                  )}
                </div>
              )}

              {activeThread?.messages.map((m) =>
                m.streaming && !m.content ? (
                  <ThinkingSphere key={m.id} label={busy ? "Working" : "Thinking"} />
                ) : (
                  <MessageBubble
                    key={m.id}
                    message={m}
                    onOpenArtifact={(artifactId) => {
                      setFocusArtifactId(artifactId);
                      setPanelTab("artifacts");
                      setPanelOpen(true);
                    }}
                  />
                )
              )}
            </div>
          </div>

          {error && (
            <div className="max-w-3xl mx-auto w-full px-6">
              <p className="text-sm text-destructive pb-2">{error}</p>
            </div>
          )}

          <div className="border-t border-foreground/10 bg-background">
            <div className="max-w-3xl mx-auto px-6 py-4">
              <div className="flex items-end gap-2 rounded-2xl border border-foreground/15 bg-secondary/40 p-2 focus-within:border-foreground/30 transition-colors">
                <Textarea
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      runAgent(goal);
                    }
                  }}
                  placeholder={
                    activeThread && activeThread.messages.length > 0
                      ? "Give the agent another goal…"
                      : "e.g. Build a landing page for a coffee subscription, with pricing and FAQ"
                  }
                  disabled={busy}
                  className="min-h-[44px] max-h-40 resize-none border-0 bg-transparent shadow-none focus-visible:ring-0 text-[15px]"
                />
                {busy ? (
                  <Button
                    type="button"
                    size="icon"
                    onClick={stop}
                    className="rounded-full shrink-0 bg-foreground text-background hover:bg-foreground/90"
                    aria-label="Stop"
                  >
                    <Square className="w-3.5 h-3.5" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    size="icon"
                    onClick={() => runAgent(goal)}
                    disabled={!goal.trim()}
                    className="rounded-full shrink-0 bg-foreground text-background hover:bg-foreground/90 disabled:opacity-30"
                    aria-label="Run agent"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <p className="text-[11px] text-muted-foreground mt-2 text-center font-mono">
                {settings.plugins.webSearch ? "Web search on · " : ""}
                {settings.model}
              </p>
            </div>
          </div>
        </div>

        {plan.length > 0 && (
          <div className="w-64 shrink-0 border-l border-foreground/10 px-4 py-6 hidden lg:block">
            <p className="text-xs font-mono uppercase tracking-wide text-muted-foreground mb-3">Plan</p>
            <div className="flex flex-col gap-3">
              {plan.map((step, i) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  {stepStatuses[i] === "done" ? (
                    <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-foreground" />
                  ) : stepStatuses[i] === "running" ? (
                    <Loader2 className="w-4 h-4 mt-0.5 shrink-0 animate-spin text-foreground" />
                  ) : (
                    <Circle className="w-4 h-4 mt-0.5 shrink-0 text-muted-foreground/40" />
                  )}
                  <span className={stepStatuses[i] === "done" ? "text-muted-foreground" : ""}>{step}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <RightPanel
        open={panelOpen}
        defaultTab={panelTab}
        thread={activeThread}
        focusArtifactId={focusArtifactId}
        onClose={() => setPanelOpen(false)}
      />

      <ApiKeysDialog open={apiKeysOpen} onOpenChange={setApiKeysOpen} />
    </div>
  );
}
