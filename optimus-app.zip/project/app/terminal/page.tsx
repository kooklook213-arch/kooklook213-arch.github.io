"use client";

import { useEffect, useRef, useState } from "react";
import { ChatSidebar } from "@/components/chat/sidebar";
import { RightPanel } from "@/components/chat/right-panel";
import { ApiKeysDialog } from "@/components/chat/api-keys-dialog";
import { useChatStore, uid, type ChatMessage, TERMINAL_SYSTEM_PROMPT } from "@/lib/chat-store";
import { extractArtifacts, stripCodeForDisplay } from "@/lib/extract-artifacts";
import { useSpeech } from "@/lib/use-speech";
import { useSkills, buildSkillsContext } from "@/lib/use-skills";
import { KeyRound, Mic, MicOff, Volume2 } from "lucide-react";

export default function TerminalPage() {
  const { activeThread, activeThreadId, appendMessage, updateMessage, settings } = useChatStore();
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [panelOpen, setPanelOpen] = useState(false);
  const [panelTab, setPanelTab] = useState<"artifacts" | "connections" | "skills">("artifacts");
  const [focusArtifactId, setFocusArtifactId] = useState<string | null>(null);
  const [apiKeysOpen, setApiKeysOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { supported, listening, startListening, stopListening, speak } = useSpeech();
  const { skills } = useSkills();

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [activeThread?.messages.length, activeThread?.messages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [activeThreadId]);

  const send = async (text: string) => {
    const content = text.trim();
    if (!content || !activeThreadId || busy) return;

    if (!settings.apiKey) {
      setError("No API key configured. Run the API keys panel first.");
      setApiKeysOpen(true);
      return;
    }

    setError("");
    setInput("");

    const userMsg: ChatMessage = { id: uid(), role: "user", content, createdAt: Date.now() };
    appendMessage(activeThreadId, userMsg, { titleIfEmpty: content });

    const assistantId = uid();
    appendMessage(activeThreadId, {
      id: assistantId,
      role: "assistant",
      content: "",
      createdAt: Date.now(),
      streaming: true,
    });

    setBusy(true);
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const history = [...(activeThread?.messages || []), userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        signal: controller.signal,
        headers: { "content-type": "application/json", "x-api-key": settings.apiKey },
        body: JSON.stringify({
          model: settings.model,
          system: TERMINAL_SYSTEM_PROMPT + buildSkillsContext(skills),
          messages: history,
          webSearch: settings.plugins.webSearch,
        }),
      });

      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Request failed (${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const jsonStr = line.slice(5).trim();
          if (!jsonStr) continue;
          try {
            const evt = JSON.parse(jsonStr);
            if (evt.type === "content_block_delta" && evt.delta?.type === "text_delta") {
              full += evt.delta.text;
              updateMessage(activeThreadId, assistantId, { content: full, streaming: true }, { persist: false });
            } else if (evt.type === "error") {
              throw new Error(evt.error?.message || "Streaming error.");
            }
          } catch {
            // ignore malformed/partial lines
          }
        }
      }

      updateMessage(activeThreadId, assistantId, { content: full, streaming: false }, { persist: true });

      if (settings.plugins.voiceOut && full) {
        const prose = stripCodeForDisplay(full);
        if (prose) speak(prose.slice(0, 600));
      }

      if (/```/.test(full)) {
        setFocusArtifactId(`${assistantId}-0`);
        setPanelOpen(true);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      updateMessage(
        activeThreadId,
        assistantId,
        { content: message.startsWith("The user aborted") ? "[stopped]" : `[error] ${message}`, streaming: false },
        { persist: true }
      );
      if (!message.startsWith("The user aborted")) setError(message);
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-black">
      <ChatSidebar
        onOpenArtifacts={() => {
          setPanelTab("artifacts");
          setPanelOpen(true);
        }}
        onOpenConnections={() => {
          setPanelTab("connections");
          setPanelOpen(true);
        }}
        onOpenSkills={() => {
          setPanelTab("skills");
          setPanelOpen(true);
        }}
        onOpenPlugins={() => {}}
        onOpenApiKeys={() => setApiKeysOpen(true)}
      />

      <main className="flex-1 flex flex-col min-w-0 bg-black text-[#e6f2e6] font-mono">
        {/* fake terminal chrome */}
        <div className="flex items-center gap-2 px-4 h-10 border-b border-white/10 shrink-0">
          <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
          <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
          <span className="w-3 h-3 rounded-full bg-[#28c840]" />
          <span className="ml-3 text-xs text-white/40">optimus — ai terminal</span>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-6">
          <div className="max-w-3xl mx-auto flex flex-col gap-4 text-[13px] leading-relaxed">
            <p className="text-white/40">
              Optimus terminal. Chat like you would with an engineer — describe what you want
              built or fixed, and it'll write the code.
            </p>
            {!settings.apiKey && (
              <button
                onClick={() => setApiKeysOpen(true)}
                className="flex items-center gap-2 text-white/60 hover:text-white w-fit border border-white/15 rounded px-3 py-1.5"
              >
                <KeyRound className="w-3.5 h-3.5" />
                set-api-key --anthropic
              </button>
            )}

            {activeThread?.messages.map((m) => (
              <TerminalLine
                key={m.id}
                message={m}
                onOpenArtifact={(id) => {
                  setFocusArtifactId(id);
                  setPanelOpen(true);
                }}
              />
            ))}

            {error && <p className="text-[#ff8080]">error: {error}</p>}
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="border-t border-white/10 px-6 py-4 shrink-0"
        >
          <div className="max-w-3xl mx-auto flex items-center gap-2">
            <span className="text-[#28c840] select-none">❯</span>
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={busy ? "working…" : "type a request and press enter"}
              disabled={busy}
              className="flex-1 bg-transparent outline-none text-[13px] placeholder:text-white/30 disabled:opacity-50"
            />
            {settings.plugins.voiceIn && supported && (
              <button
                type="button"
                onClick={() =>
                  listening
                    ? stopListening()
                    : startListening((finalText) =>
                        setInput((prev) => (prev ? prev + " " + finalText : finalText))
                      )
                }
                className={`text-[11px] border rounded px-2 py-1 flex items-center gap-1 ${
                  listening
                    ? "border-[#ff5f57]/50 text-[#ff8080]"
                    : "border-white/15 text-white/40 hover:text-white/70"
                }`}
              >
                {listening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
              </button>
            )}
            {settings.plugins.voiceOut && (
              <span className="text-white/25" title="Voice replies on">
                <Volume2 className="w-3.5 h-3.5" />
              </span>
            )}
            {busy && (
              <button
                type="button"
                onClick={() => abortRef.current?.abort()}
                className="text-[11px] text-white/40 hover:text-white/70 border border-white/15 rounded px-2 py-1"
              >
                ctrl+c
              </button>
            )}
          </div>
        </form>
      </main>

      <RightPanel
        open={panelOpen}
        defaultTab={panelTab}
        thread={activeThread}
        focusArtifactId={focusArtifactId}
        onClose={() => setPanelOpen(false)}
        onUseSkill={(code, title) => {
          setInput((prev) => (prev ? prev + " " : "") + `Here's my saved "${title}" skill:\n\n\`\`\`\n${code}\n\`\`\`\n\n`);
          setPanelOpen(false);
        }}
      />

      <ApiKeysDialog open={apiKeysOpen} onOpenChange={setApiKeysOpen} />
    </div>
  );
}

function TerminalLine({
  message,
  onOpenArtifact,
}: {
  message: ChatMessage;
  onOpenArtifact: (id: string) => void;
}) {
  if (message.role === "user") {
    return (
      <p>
        <span className="text-[#28c840]">❯</span>{" "}
        <span className="text-white">{message.content}</span>
      </p>
    );
  }

  if (message.streaming && !message.content) {
    return <p className="text-white/40 animate-pulse">…thinking</p>;
  }

  const artifacts = extractArtifacts(message.content, message.id);
  const prose = stripCodeForDisplay(message.content);

  return (
    <div className="pl-4 border-l border-white/10 whitespace-pre-wrap text-white/85">
      {prose}
      {message.streaming && <span className="inline-block w-1.5 h-3.5 bg-[#28c840] ml-0.5 align-middle animate-pulse" />}
      {artifacts.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {artifacts.map((a) => (
            <button
              key={a.id}
              onClick={() => onOpenArtifact(a.id)}
              className="text-[11px] border border-white/15 rounded px-2 py-1 text-white/60 hover:text-white hover:border-white/30"
            >
              [{a.language}] {a.title || "open"} →
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
