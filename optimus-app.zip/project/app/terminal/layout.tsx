"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { ChatProvider } from "@/lib/chat-store";

export default function TerminalLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/signin");
    }
  }, [loading, user, router]);

  if (loading || !user) {
    return <main className="min-h-screen bg-black" />;
  }

  return <ChatProvider kind="terminal">{children}</ChatProvider>;
}
