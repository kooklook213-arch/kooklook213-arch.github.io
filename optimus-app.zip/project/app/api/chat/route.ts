import { NextRequest } from "next/server";

export const runtime = "nodejs";

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_VERSION = "2023-06-01";

type IncomingMessage = { role: "user" | "assistant"; content: string };

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get("x-api-key");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Missing API key." }), { status: 401 });
  }

  const body = await req.json();
  const messages: IncomingMessage[] = body.messages || [];
  const model: string = body.model || "claude-sonnet-5";
  const system: string = body.system || "";
  const webSearch: boolean = !!body.webSearch;

  const anthropicBody: Record<string, unknown> = {
    model,
    max_tokens: 4096,
    system,
    messages: messages.map((m) => ({ role: m.role, content: m.content })),
    stream: true,
  };

  if (webSearch) {
    anthropicBody.tools = [{ type: "web_search_20250305", name: "web_search" }];
  }

  let upstream: Response;
  try {
    upstream = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": ANTHROPIC_VERSION,
      },
      body: JSON.stringify(anthropicBody),
    });
  } catch {
    return new Response(JSON.stringify({ error: "Failed to reach the Anthropic API." }), {
      status: 502,
    });
  }

  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text().catch(() => "");
    return new Response(
      JSON.stringify({ error: `Anthropic API error (${upstream.status}): ${text.slice(0, 500)}` }),
      { status: upstream.status || 500 }
    );
  }

  // Pipe the SSE stream straight through to the client.
  return new Response(upstream.body, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache",
      connection: "keep-alive",
    },
  });
}
