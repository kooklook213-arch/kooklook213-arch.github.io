import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest, uid } from "@/lib/server/auth";
import { db, type SkillRow } from "@/lib/server/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });

  const rows = db
    .prepare("SELECT * FROM skills WHERE user_id = ? ORDER BY created_at DESC")
    .all(user.id) as SkillRow[];

  return NextResponse.json({
    skills: rows.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      language: r.language,
      code: r.code,
      createdAt: r.created_at,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });

  const { title, description, language, code } = await req.json().catch(() => ({}));
  if (!title || !code) {
    return NextResponse.json({ error: "title and code are required." }, { status: 400 });
  }

  const id = uid();
  const now = Date.now();
  db.prepare(
    "INSERT INTO skills (id, user_id, title, description, language, code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(id, user.id, String(title).slice(0, 120), String(description || "").slice(0, 400), String(language || "text"), String(code), now);

  return NextResponse.json({
    skill: { id, title, description: description || "", language: language || "text", code, createdAt: now },
  });
}
