import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/server/auth";
import { db } from "@/lib/server/db";

export const runtime = "nodejs";

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { id } = await ctx.params;

  const row = db.prepare("SELECT id FROM skills WHERE id = ? AND user_id = ?").get(id, user.id);
  if (!row) return NextResponse.json({ error: "Not found." }, { status: 404 });

  db.prepare("DELETE FROM skills WHERE id = ?").run(id);
  return NextResponse.json({ ok: true });
}
