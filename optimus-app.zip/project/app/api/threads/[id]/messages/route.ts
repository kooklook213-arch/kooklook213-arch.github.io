import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/server/auth";
import { db, type ThreadRow } from "@/lib/server/db";

export const runtime = "nodejs";

function ownedThread(userId: string, threadId: string): ThreadRow | null {
  const t = db.prepare("SELECT * FROM threads WHERE id = ? AND user_id = ?").get(threadId, userId) as
    | ThreadRow
    | undefined;
  return t ?? null;
}

// Append a new message, and optionally rename the thread in the same call
// (used for the first user message in a fresh thread).
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { id: threadId } = await ctx.params;
  if (!ownedThread(user.id, threadId)) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const { id, role, content, titleIfEmpty } = await req.json().catch(() => ({}));
  if (!id || !role || typeof content !== "string") {
    return NextResponse.json({ error: "id, role, and content are required." }, { status: 400 });
  }

  db.prepare(
    "INSERT INTO messages (id, thread_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)"
  ).run(id, threadId, role, content, Date.now());

  if (titleIfEmpty) {
    const count = db.prepare("SELECT COUNT(*) as c FROM messages WHERE thread_id = ?").get(threadId) as {
      c: number;
    };
    if (count.c === 1) {
      db.prepare("UPDATE threads SET title = ? WHERE id = ?").run(
        String(titleIfEmpty).slice(0, 48),
        threadId
      );
    }
  }

  return NextResponse.json({ ok: true });
}

// Update an existing message's content (used while a streamed reply is filling in).
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { id: threadId } = await ctx.params;
  if (!ownedThread(user.id, threadId)) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const { id, content } = await req.json().catch(() => ({}));
  if (!id || typeof content !== "string") {
    return NextResponse.json({ error: "id and content are required." }, { status: 400 });
  }

  db.prepare("UPDATE messages SET content = ? WHERE id = ? AND thread_id = ?").run(content, id, threadId);
  return NextResponse.json({ ok: true });
}
