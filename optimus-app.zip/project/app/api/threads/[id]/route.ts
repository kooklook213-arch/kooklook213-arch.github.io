import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/server/auth";
import { db, type ThreadRow } from "@/lib/server/db";

export const runtime = "nodejs";

function ownedThread(userId: string, threadId: string): ThreadRow | null {
  const t = db.prepare("SELECT * FROM threads WHERE id = ? AND user_id = ?").get(threadId, userId) as
    | ThreadRow
    | undefined;
  return t ?? null;
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { id } = await ctx.params;
  if (!ownedThread(user.id, id)) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const { title } = await req.json().catch(() => ({}));
  if (typeof title === "string") {
    db.prepare("UPDATE threads SET title = ? WHERE id = ?").run(title.slice(0, 120), id);
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { id } = await ctx.params;
  if (!ownedThread(user.id, id)) return NextResponse.json({ error: "Not found." }, { status: 404 });

  db.prepare("DELETE FROM messages WHERE thread_id = ?").run(id);
  db.prepare("DELETE FROM threads WHERE id = ?").run(id);
  return NextResponse.json({ ok: true });
}
