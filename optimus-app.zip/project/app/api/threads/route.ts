import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest, uid } from "@/lib/server/auth";
import { db, type MessageRow, type ThreadRow } from "@/lib/server/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });

  const kind = req.nextUrl.searchParams.get("kind") || "chat";

  const threads = db
    .prepare("SELECT * FROM threads WHERE user_id = ? AND kind = ? ORDER BY created_at DESC")
    .all(user.id, kind) as ThreadRow[];

  const withMessages = threads.map((t) => {
    const messages = db
      .prepare("SELECT * FROM messages WHERE thread_id = ? ORDER BY created_at ASC")
      .all(t.id) as MessageRow[];
    return {
      id: t.id,
      title: t.title,
      kind: t.kind,
      createdAt: t.created_at,
      messages: messages.map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        createdAt: m.created_at,
      })),
    };
  });

  return NextResponse.json({ threads: withMessages });
}

export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const kind = ["terminal", "agent", "jobs"].includes(body.kind) ? body.kind : "chat";

  const id = uid();
  const now = Date.now();
  db.prepare(
    "INSERT INTO threads (id, user_id, title, kind, created_at) VALUES (?, ?, ?, ?, ?)"
  ).run(id, user.id, "New chat", kind, now);

  return NextResponse.json({ thread: { id, title: "New chat", kind, createdAt: now, messages: [] } });
}
