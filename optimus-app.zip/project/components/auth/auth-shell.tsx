"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { AnimatedSphere } from "@/components/landing/animated-sphere";

export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <main className="relative min-h-screen overflow-hidden noise-overlay flex">
      {/* Grid lines, same language as the landing hero */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
        {[...Array(8)].map((_, i) => (
          <div
            key={`h-${i}`}
            className="absolute h-px bg-foreground/10"
            style={{ top: `${12.5 * (i + 1)}%`, left: 0, right: 0 }}
          />
        ))}
        {[...Array(12)].map((_, i) => (
          <div
            key={`v-${i}`}
            className="absolute w-px bg-foreground/10"
            style={{ left: `${8.33 * (i + 1)}%`, top: 0, bottom: 0 }}
          />
        ))}
      </div>

      {/* Left: form */}
      <div className="relative z-10 w-full lg:w-[520px] flex flex-col px-8 lg:px-16 py-10">
        <Link href="/" className="flex items-center gap-2 group w-fit">
          <span className="font-display text-2xl tracking-tight">Optimus</span>
          <span className="text-muted-foreground font-mono text-xs mt-1">TM</span>
        </Link>

        <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full py-16">
          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-4">
            <span className="w-8 h-px bg-foreground/30" />
            Account
          </span>
          <h1 className="text-4xl font-display tracking-tight mb-3 leading-[0.95]">
            {title}
          </h1>
          <p className="text-muted-foreground mb-10 leading-relaxed">{subtitle}</p>

          {children}

          <div className="mt-10 pt-6 border-t border-foreground/10 text-sm text-muted-foreground">
            {footer}
          </div>
        </div>
      </div>

      {/* Right: animated sphere, same as hero */}
      <div className="relative hidden lg:flex flex-1 items-center justify-center border-l border-foreground/10 overflow-hidden">
        <div className="w-[700px] h-[700px] opacity-50">
          <AnimatedSphere />
        </div>
        <div className="absolute bottom-16 left-16 right-16">
          <p className="text-sm font-mono text-muted-foreground mb-2">01 / AI WORKSPACE</p>
          <p className="text-2xl font-display leading-snug max-w-md">
            Chat, build, and ship — with artifacts, plugins, and live web search
            in one place.
          </p>
        </div>
      </div>
    </main>
  );
}
