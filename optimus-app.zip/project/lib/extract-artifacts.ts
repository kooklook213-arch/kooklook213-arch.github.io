export type Artifact = {
  id: string;
  language: string;
  code: string;
  title: string;
  /** true for languages we can render a live preview for */
  previewable: boolean;
};

const FENCE_RE = /```([a-zA-Z0-9_+-]*)\n([\s\S]*?)```/g;

const PREVIEWABLE = new Set(["html", "htm", "jsx", "tsx", "threejs", "three"]);

const LANGUAGE_LABELS: Record<string, string> = {
  html: "Website",
  htm: "Website",
  jsx: "React component",
  tsx: "React component",
  threejs: "3D scene",
  three: "3D scene",
  js: "Script",
  javascript: "Script",
  ts: "Script",
  typescript: "Script",
  py: "Python script",
  python: "Python script",
  css: "Stylesheet",
  json: "Data",
  md: "Document",
  markdown: "Document",
  sql: "Query",
};

const MIN_LINES_TO_COUNT_AS_ARTIFACT = 3;

export function extractArtifacts(content: string, seedId: string): Artifact[] {
  const artifacts: Artifact[] = [];
  let match: RegExpExecArray | null;
  let index = 0;
  FENCE_RE.lastIndex = 0;
  while ((match = FENCE_RE.exec(content)) !== null) {
    const rawLang = (match[1] || "text").toLowerCase();
    const code = match[2].trim();
    if (code.split("\n").length < MIN_LINES_TO_COUNT_AS_ARTIFACT) continue;
    const label = LANGUAGE_LABELS[rawLang] || rawLang.toUpperCase();
    artifacts.push({
      id: `${seedId}-${index}`,
      language: rawLang,
      code,
      title: `${label} ${index > 0 ? index + 1 : ""}`.trim(),
      previewable: PREVIEWABLE.has(rawLang),
    });
    index++;
  }
  return artifacts;
}

/** Strip fenced code blocks out of prose for a compact inline preview, keeping a placeholder. */
export function stripCodeForDisplay(content: string): string {
  return content.replace(FENCE_RE, "").trim();
}

/**
 * Builds the document to load into the preview iframe.
 * - HTML artifacts are self-contained already.
 * - "threejs" artifacts get wrapped with the Three.js r128 UMD build and a
 *   full-viewport <canvas id="scene">, for 3D scenes and games.
 * - JSX/TSX artifacts get wrapped with React, Babel standalone (for
 *   in-browser JSX transpilation), and Tailwind's CDN build so a component
 *   defined as `function App() { ... }` renders with no bundler.
 * Contract for both non-HTML cases: no import/export statements — the
 * globals (THREE, or React/ReactDOM + hooks) are provided by the page.
 */
export function buildPreviewDoc(artifact: Artifact): string {
  if (artifact.language === "html" || artifact.language === "htm") {
    return artifact.code;
  }

  const safeCode = artifact.code.replace(/<\/script/gi, "<\\/script");

  if (artifact.language === "threejs" || artifact.language === "three") {
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="https://unpkg.com/three@0.128.0/build/three.min.js"></script>
<style>html,body{height:100%;margin:0;overflow:hidden;background:#0a0a0a}
#scene{display:block;width:100vw;height:100vh}
#err{display:none;color:#ff8080;padding:16px;white-space:pre-wrap;font-family:monospace;background:#111}</style>
</head>
<body>
<canvas id="scene"></canvas>
<pre id="err"></pre>
<script>
try {
${safeCode}
} catch (e) {
  var el = document.getElementById("err");
  el.style.display = "block";
  el.textContent = (e && e.message) ? e.message : String(e);
}
</script>
</body>
</html>`;
  }

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="https://unpkg.com/react@18/umd/react.development.js"></script>
<script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
<script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>html,body,#root{height:100%;margin:0}</style>
</head>
<body>
<div id="root"></div>
<script type="text/babel" data-presets="react">
${safeCode}

try {
  const rootEl = document.getElementById("root");
  const root = ReactDOM.createRoot(rootEl);
  root.render(React.createElement(typeof App !== "undefined" ? App : () => null));
} catch (e) {
  document.getElementById("root").innerHTML =
    '<pre style="color:#c0392b;padding:16px;white-space:pre-wrap;font-family:monospace">' +
    (e && e.message ? e.message : String(e)) +
    "</pre>";
}
</script>
</body>
</html>`;
}
